name = input("What is your Name?")
if name:
    print("Greetings " + name)
else:
    print("Greetings Stranger")