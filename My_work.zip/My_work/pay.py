hour=int(input("Enter the number of hours Worked: "))
rate=int(input("Enter the hourly pay rate: "))
pay=hour*rate;
print("Pay: " ,pay)