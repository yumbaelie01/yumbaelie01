name = input("What is your Name?")
print("Greetings " + name)
